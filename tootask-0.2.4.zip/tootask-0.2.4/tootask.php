<?php
/**
 * Plugin Name: TooTask
 * Description: SPA via shortcode [tootask], auth (login/register) y Tasks REST. Detección robusta de assets + soporte type=module.
 * Version: 0.2.4
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: ccaguasdevida
 * Text Domain: tootask
 */
if (!defined('ABSPATH')) { exit; }
define('TOOTASK_VERSION','0.2.4');
define('TOOTASK_PLUGIN_FILE', __FILE__);
define('TOOTASK_DIR', plugin_dir_path(__FILE__));
define('TOOTASK_URL', plugin_dir_url(__FILE__));

function tootask_file_version($relative){
  $p = TOOTASK_DIR . ltrim($relative,'/');
  return file_exists($p) ? (string) filemtime($p) : TOOTASK_VERSION;
}

/** Descubre assets en public/build y marca si son ES Modules (Vite) */
function tootask_discover_assets(){
  $dir = TOOTASK_DIR . 'public/build/';
  $url = TOOTASK_URL . 'public/build/';
  $out = ['js'=>[], 'css'=>[], 'module'=>false];

  if (file_exists($dir)) {
    // 1) Vite manifest.json
    if (file_exists($dir . 'manifest.json')) {
      $m = json_decode(file_get_contents($dir . 'manifest.json'), true);
      if (is_array($m)) {
        foreach ($m as $entry) {
          if (!empty($entry['isEntry'])) $out['module'] = true; // Vite produce ESM
          if (!empty($entry['file']) && preg_match('/\.js$/', $entry['file'])) $out['js'][] = $url . $entry['file'];
          if (!empty($entry['css']) && is_array($entry['css'])) foreach($entry['css'] as $c) $out['css'][] = $url . $c;
        }
      }
    }
    // 2) index-*.js/css (pueden ser ESM también, pero no lo sabemos)
    if (empty($out['js'])) foreach (glob($dir . 'index-*.js') as $f) $out['js'][] = $url . basename($f);
    if (empty($out['css'])) foreach (glob($dir . 'index-*.css') as $f) $out['css'][] = $url . basename($f);
    // 3) index.js/css
    if (empty($out['js']) && file_exists($dir . 'index.js')) $out['js'][] = $url . 'index.js';
    if (empty($out['css']) && file_exists($dir . 'index.css')) $out['css'][] = $url . 'index.css';
  }
  return $out;
}

require_once TOOTASK_DIR . 'includes/class-tootask-admin.php';
require_once TOOTASK_DIR . 'includes/class-tootask-auth.php';
require_once TOOTASK_DIR . 'includes/class-tootask-tasks.php';
require_once TOOTASK_DIR . 'public/shortcodes.php';

register_activation_hook(__FILE__, function(){
  if (!get_role('tootask_user')) add_role('tootask_user','TooTask User',['read'=>true]);
  TooTask_Tasks::register_cpt(); flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function(){ flush_rewrite_rules(); });

add_action('plugins_loaded', function(){
  if (is_admin()) $GLOBALS['tootask_admin'] = new TooTask_Admin();
  $GLOBALS['tootask_auth']  = new TooTask_Auth();
  $GLOBALS['tootask_tasks'] = new TooTask_Tasks();
});
