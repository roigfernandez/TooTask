(function(){
  function api(m,p,d){ return fetch((window.TooTask?TooTask.restUrl:'/wp-json/tootask/v1/')+p,{method:m,headers:{'Content-Type':'application/json','X-WP-Nonce':(window.TooTask?TooTask.wpRestNonce:'')},credentials:'same-origin',body:m==='GET'||m==='DELETE'?null:JSON.stringify(d||{})}).then(r=>r.json()); }
  function q(id){ return document.getElementById(id); }
  function h(s){ return (s||'').replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];}); }
  function mount(){
    var root=document.getElementById('root'); if(!root) return;
    root.innerHTML=['<div class="tt-card">','<h2 class="tt-title">Inicia sesión</h2>','<div id="msg" class="tt-msg"></div>','<div class="tt-row"><input id="u" class="tt-input" placeholder="Usuario o email" /></div>','<div class="tt-row"><input id="p" class="tt-input" placeholder="Contraseña" type="password" /></div>','<div class="tt-actions">','<button id="loginBtn" class="tt-btn">Entrar</button>','<button id="meBtn" class="tt-link">¿Quién soy?</button>','<button id="logoutBtn" class="tt-link">Salir</button>','</div>','<hr class="tt-sep"/>','<div class="tt-row">','<input id="t" class="tt-input" placeholder="Nueva tarea..." />','<button id="add" class="tt-btn">Agregar</button>','</div>','<ul id="tasks" class="tt-list"></ul>','</div>'].join('');
    function show(o){ q('msg').textContent=typeof o==='string'?o:JSON.stringify(o); }
    function load(){ api('GET','me').then(function(me){ if(me&&me.success){ show('Hola, '+h(me.user.username)); list(); } else { show('No logueado'); } }); }
    function list(){ api('GET','tasks').then(function(r){ var ul=q('tasks'); ul.innerHTML=''; (r.items||[]).forEach(function(it){ var li=document.createElement('li'); li.className='tt-item'; li.innerHTML=h(it.title)+' <button data-id="'+it.id+'" class="tt-del">×</button>'; li.querySelector('button').addEventListener('click', function(){ api('DELETE','tasks/'+it.id).then(load); }); ul.appendChild(li); }); }); }
    q('loginBtn').addEventListener('click', function(){ api('POST','login',{username:q('u').value,password:q('p').value}).then(function(r){ if(r&&r.success){ show('Login OK'); list(); } else { show(r); } }); });
    q('meBtn').addEventListener('click', load);
    q('logoutBtn').addEventListener('click', function(){ api('POST','logout').then(load); });
    q('add').addEventListener('click', function(){ var v=q('t').value.trim(); if(!v) return; api('POST','tasks',{title:v}).then(function(){ q('t').value=''; list(); }); });
    load();
  }
  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', mount); } else { mount(); }
})();