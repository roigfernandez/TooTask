<?php
if (!defined('ABSPATH')) { exit; }

function tootask_enqueue_frontend_assets(){
  $assets = tootask_discover_assets();
  $enqueued = false;
  $module_handles = [];

  if (!empty($assets['css'])) {
    foreach ($assets['css'] as $i => $css) {
      $h = 'tootask-frontend-css-' . $i;
      $rel = str_replace(TOOTASK_URL, '', $css);
      wp_enqueue_style($h, $css, [], tootask_file_version($rel));
    }
  }
  if (!empty($assets['js'])) {
    foreach ($assets['js'] as $i => $js) {
      $h = 'tootask-frontend-js-' . $i;
      $rel = str_replace(TOOTASK_URL, '', $js);
      wp_enqueue_script($h, $js, [], tootask_file_version($rel), true);
      if (!empty($assets['module'])) {
        // WP 6.3+: soporta 'type' vía add_data; añadimos filtro de respaldo por compatibilidad.
        if (function_exists('wp_script_add_data')) { wp_script_add_data($h, 'type', 'module'); }
        $module_handles[] = $h;
      }
      $enqueued = true;
    }
  }

  // Filtro para forzar type="module" si el tema/WP no soporta wp_script_add_data
  if (!empty($module_handles)) {
    add_filter('script_loader_tag', function($tag, $handle) use ($module_handles){
      if (in_array($handle, $module_handles, true)) {
        if (strpos($tag, 'type=') === false) {
          $tag = str_replace('<script ', '<script type="module" ', $tag);
        }
      }
      return $tag;
    }, 10, 2);
  }

  // Localización de datos para SPA o fallback
  wp_register_script('tootask-fallback', TOOTASK_URL . 'public/fallback/fallback.js', [], tootask_file_version('public/fallback/fallback.js'), true);
  wp_localize_script('tootask-fallback', 'TooTask', [
    'restUrl'     => esc_url_raw( rest_url('tootask/v1/') ),
    'wpRestNonce' => wp_create_nonce('wp_rest'),
    'homeUrl'     => home_url('/')
  ]);

  if (!$enqueued) {
    wp_enqueue_style('tootask-fallback', TOOTASK_URL . 'public/fallback/fallback.css', [], tootask_file_version('public/fallback/fallback.css'));
    wp_enqueue_script('tootask-fallback');
  } else {
    wp_add_inline_script('tootask-frontend-js-0', 'window.TooTask = Object.assign(window.TooTask||{}, {restUrl: "' . esc_url_raw( rest_url('tootask/v1/') ) . '", wpRestNonce: "' . wp_create_nonce('wp_rest') . '", homeUrl: "' . home_url('/') . '"});', 'before');
  }
}

function tootask_shortcode($atts = [], $content = null){
  tootask_enqueue_frontend_assets();
  ob_start(); ?><div id="root" class="tootask-root"></div><?php return ob_get_clean();
}
add_shortcode('tootask','tootask_shortcode');
