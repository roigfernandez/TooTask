<?php
if (!defined('ABSPATH')) { exit; }
class TooTask_Auth {
  const NS='tootask/v1';
  public function __construct(){ add_action('rest_api_init',[$this,'routes']); }
  public function routes(){
    register_rest_route(self::NS,'/me',['methods'=>'GET','permission_callback'=>'__return_true','callback'=>[$this,'me']]);
    register_rest_route(self::NS,'/login',['methods'=>'POST','permission_callback'=>'__return_true','callback'=>[$this,'login']]);
    register_rest_route(self::NS,'/logout',['methods'=>'POST','permission_callback'=>function(){return is_user_logged_in();},'callback'=>[$this,'logout']]);
    register_rest_route(self::NS,'/register',['methods'=>'POST','permission_callback'=>'__return_true','callback'=>[$this,'register']]);
  }
  private function user_payload($u){ return ['id'=>(int)$u->ID,'username'=>$u->user_login,'name'=>$u->display_name,'roles'=>array_values((array)$u->roles)]; }
  private function throttle_key($u){ $ip=$_SERVER['REMOTE_ADDR']??'0.0.0.0'; return 'tootask_login_'.md5(strtolower($u).'|'.$ip); }
  public function me($r){ if(is_user_logged_in()){ $u=wp_get_current_user(); return new WP_REST_Response(['success'=>true,'user'=>$this->user_payload($u),'nonce'=>wp_create_nonce('wp_rest')],200);} return new WP_REST_Response(['success'=>false],200); }
  public function login($r){
    $p=$r->get_json_params(); if(empty($p)) $p=$r->get_body_params();
    $username=isset($p['username'])? trim(sanitize_text_field($p['username'])):'';
    $password=isset($p['password'])? (string)$p['password']:'';
    $remember=!empty($p['remember']);
    if($username===''||$password===''){ return new WP_Error('tootask_login_missing',__('Usuario y contraseña requeridos','tootask'),['status'=>400]); }
    if(strpos($username,'@')!==false){ $email=strtolower($username); $email=preg_replace('/\s+/','',$email); $u=get_user_by('email',sanitize_email($email)); if($u){ $username=$u->user_login; } }
    $tkey=$this->throttle_key($username); $attempts=(int)get_transient($tkey); if($attempts>20){ return new WP_Error('tootask_login_throttle',__('Demasiados intentos. Intenta más tarde.','tootask'),['status'=>429]); }
    $creds=['user_login'=>$username,'user_password'=>$password,'remember'=>$remember]; $user=wp_signon($creds,is_ssl());
    if(is_wp_error($user)){ set_transient($tkey,$attempts+1,10*MINUTE_IN_SECONDS); return new WP_Error('tootask_login_failed',__('Credenciales inválidas.','tootask'),['status'=>401]); }
    delete_transient($tkey); wp_set_current_user($user->ID); wp_set_auth_cookie($user->ID,$remember);
    return new WP_REST_Response(['success'=>true,'user'=>$this->user_payload($user),'nonce'=>wp_create_nonce('wp_rest')],200);
  }
  public function logout($r){ wp_logout(); return new WP_REST_Response(['success'=>true],200); }
  public function register($r){
    if(!get_option('users_can_register')){ return new WP_Error('tootask_register_closed',__('El registro de usuarios está deshabilitado.','tootask'),['status'=>403]); }
    $p=$r->get_json_params(); if(empty($p)) $p=$r->get_body_params();
    $username=isset($p['username'])? sanitize_user($p['username']):'';
    $email=isset($p['email'])? sanitize_email(strtolower(trim($p['email']))):'';
    $password=isset($p['password'])? (string)$p['password']:'';
    if($username===''||$email===''){ return new WP_Error('tootask_register_missing',__('Usuario y correo son requeridos','tootask'),['status'=>400]); }
    if(username_exists($username)){ return new WP_Error('tootask_register_username',__('El usuario ya existe','tootask'),['status'=>409]); }
    if(email_exists($email)){ return new WP_Error('tootask_register_email',__('El correo ya está registrado','tootask'),['status'=>409]); }
    if($password!==''&&strlen($password)<8){ return new WP_Error('tootask_register_weak',__('La contraseña debe tener al menos 8 caracteres','tootask'),['status'=>400]); }
    if($password===''){ $password=wp_generate_password(12,true); }
    $uid=wp_create_user($username,$password,$email); if(is_wp_error($uid)){ return new WP_Error('tootask_register_failed',$uid->get_error_message(),['status'=>500]); }
    $u=get_user_by('id',$uid); $u->set_role('tootask_user'); wp_set_current_user($uid); wp_set_auth_cookie($uid,false);
    return new WP_REST_Response(['success'=>true,'user'=>$this->user_payload($u),'nonce'=>wp_create_nonce('wp_rest')],201);
  }
}