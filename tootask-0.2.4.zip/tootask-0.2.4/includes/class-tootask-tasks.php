<?php
if (!defined('ABSPATH')) { exit; }
class TooTask_Tasks {
  const CPT='tootask_task'; const NS='tootask/v1';
  public function __construct(){ add_action('init',[__CLASS__,'register_cpt']); add_action('rest_api_init',[$this,'routes']); }
  public static function register_cpt(){
    register_post_type(self::CPT,[ 'labels'=>['name'=>__('Tasks','tootask'),'singular_name'=>__('Task','tootask')], 'public'=>false,'show_ui'=>true,'show_in_menu'=>false,'supports'=>['title','editor','author'],'map_meta_cap'=>true ]);
  }
  public function routes(){
    register_rest_route(self::NS,'/tasks',['methods'=>'GET','permission_callback'=>function(){return is_user_logged_in();},'callback'=>[$this,'list']]);
    register_rest_route(self::NS,'/tasks',['methods'=>'POST','permission_callback'=>function(){return is_user_logged_in();},'callback'=>[$this,'create']]);
    register_rest_route(self::NS,'/tasks/(?P<id>\d+)',['methods'=>'GET','permission_callback'=>function($r){return $this->can_read((int)$r['id']);},'callback'=>[$this,'get']]);
    register_rest_route(self::NS,'/tasks/(?P<id>\d+)',['methods'=>'PUT,PATCH','permission_callback'=>function($r){return $this->can_read((int)$r['id']);},'callback'=>[$this,'update']]);
    register_rest_route(self::NS,'/tasks/(?P<id>\d+)',['methods'=>'DELETE','permission_callback'=>function($r){return $this->can_read((int)$r['id']);},'callback'=>[$this,'delete']]);
  }
  private function payload($p){ return ['id'=>(int)$p->ID,'title'=>get_the_title($p),'content'=>$p->post_content,'author'=>(int)$p->post_author,'status'=>get_post_meta($p->ID,'_tootask_status',true)?:'open']; }
  private function can_read($id){ $p=get_post($id); if(!$p||$p->post_type!==self::CPT) return false; if(current_user_can('manage_options')) return true; return (int)$p->post_author===get_current_user_id(); }
  public function list($r){ $q=new WP_Query(['post_type'=>self::CPT,'author'=>get_current_user_id(),'posts_per_page'=>50,'no_found_rows'=>true]); return new WP_REST_Response(['success'=>true,'items'=>array_map([$this,'payload'],$q->posts)],200); }
  public function create($r){ $d=$r->get_json_params(); if(empty($d)) $d=$r->get_body_params(); $title=isset($d['title'])? sanitize_text_field($d['title']):''; if($title==='') return new WP_Error('tootask_task_title','Title required',['status'=>400]); $id=wp_insert_post(['post_type'=>self::CPT,'post_title'=>$title,'post_status'=>'publish','post_author'=>get_current_user_id()]); if(is_wp_error($id)) return new WP_Error('tootask_task_create',$id->get_error_message(),['status'=>500]); return new WP_REST_Response(['success'=>true,'item'=>$this->payload(get_post($id))],201); }
  public function get($r){ $id=(int)$r['id']; $p=get_post($id); if(!$p) return new WP_Error('tootask_task_nf','Task not found',['status'=>404]); return new WP_REST_Response(['success'=>true,'item'=>$this->payload($p)],200); }
  public function update($r){ $id=(int)$r['id']; $d=$r->get_json_params(); if(empty($d)) $d=$r->get_body_params(); $pa=['ID'=>$id]; if(isset($d['title'])) $pa['post_title']=sanitize_text_field($d['title']); if(isset($d['content'])) $pa['post_content']=wp_kses_post($d['content']); if(count($pa)>1){ $res=wp_update_post($pa,true); if(is_wp_error($res)) return new WP_Error('tootask_task_update',$res->get_error_message(),['status'=>500]); } return new WP_REST_Response(['success'=>true,'item'=>$this->payload(get_post($id))],200); }
  public function delete($r){ $id=(int)$r['id']; $ok=wp_trash_post($id); if(!$ok) return new WP_Error('tootask_task_delete','Delete failed',['status'=>500]); return new WP_REST_Response(['success'=>true],200); }
}