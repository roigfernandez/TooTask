<?php
if (!defined('ABSPATH')) { exit; }
class TooTask_Admin {
  public function __construct(){ add_action('admin_menu',[$this,'menu']); add_action('admin_enqueue_scripts',[$this,'assets']); }
  public function menu(){
    add_menu_page(__('TooTask','tootask'),__('TooTask','tootask'),'manage_options','tootask',[$this,'render'],'dashicons-yes',26);
    add_submenu_page('tootask',__('Tasks','tootask'),__('Tasks','tootask'),'edit_posts','edit.php?post_type=tootask_task');
  }
  public function assets($hook){
    if($hook!=='toplevel_page_tootask') return;
    wp_enqueue_style('tootask-admin',TOOTASK_URL.'admin/css/admin.css',[],tootask_file_version('admin/css/admin.css'));
    wp_enqueue_script('tootask-admin',TOOTASK_URL.'admin/js/admin.js',[],tootask_file_version('admin/js/admin.js'),true);
    wp_localize_script('tootask-admin','TootaskAdmin',['restUrl'=>esc_url_raw(rest_url('tootask/v1/')),'nonce'=>wp_create_nonce('wp_rest')]);
  }
  public function render(){ echo '<div class="wrap tootask-admin-wrap"><h1>TooTask - Panel</h1><div id="tootask-admin-app"></div></div>'; }
}